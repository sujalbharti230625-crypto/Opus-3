// Coinbase API helper for fetching ETH-USDT candle data

export interface RawCandle {
  timestamp: number;
  low: number;
  high: number;
  open: number;
  close: number;
  volume: number;
}

const BASE_URL = 'https://api.exchange.coinbase.com';

const GRANULARITY_MAP: Record<string, number> = {
  '15m': 900,
  '1h': 3600,
  '4h': 21600,
  '1d': 86400,
};

export async function fetchCandles(
  timeframe: string = '1h',
  limit: number = 300
): Promise<RawCandle[]> {
  const granularity = GRANULARITY_MAP[timeframe] ?? 3600;
  const end = new Date();
  const start = new Date(end.getTime() - granularity * limit * 1000);

  const url = `${BASE_URL}/products/ETH-USDT/candles?granularity=${granularity}&start=${start.toISOString()}&end=${end.toISOString()}`;

  try {
    const res = await fetch(url, {
      headers: { 'Content-Type': 'application/json' },
      next: { revalidate: 0 },
    });

    if (!res.ok) {
      // Fallback to ETH-USD if ETH-USDT fails
      const fallbackUrl = `${BASE_URL}/products/ETH-USD/candles?granularity=${granularity}&start=${start.toISOString()}&end=${end.toISOString()}`;
      const fallbackRes = await fetch(fallbackUrl, {
        headers: { 'Content-Type': 'application/json' },
        next: { revalidate: 0 },
      });
      if (!fallbackRes.ok) throw new Error(`Coinbase API error: ${fallbackRes.status}`);
      const data = await fallbackRes.json();
      return parseCandles(data);
    }

    const data = await res.json();
    return parseCandles(data);
  } catch (error: any) {
    console.error('Failed to fetch candles:', error?.message);
    return [];
  }
}

function parseCandles(data: any[]): RawCandle[] {
  if (!Array.isArray(data)) return [];
  return data
    .map((d: any) => ({
      timestamp: (d?.[0] ?? 0) * 1000,
      low: d?.[1] ?? 0,
      high: d?.[2] ?? 0,
      open: d?.[3] ?? 0,
      close: d?.[4] ?? 0,
      volume: d?.[5] ?? 0,
    }))
    .sort((a: RawCandle, b: RawCandle) => a.timestamp - b.timestamp);
}

// Fetch historical data in batches (for backtesting - up to 2 years)
export async function fetchHistoricalCandles(
  timeframe: string = '1h',
  daysBack: number = 730
): Promise<RawCandle[]> {
  const granularity = GRANULARITY_MAP[timeframe] ?? 3600;
  const allCandles: RawCandle[] = [];
  const now = Date.now();
  const batchSize = 300;
  const batchDuration = granularity * batchSize * 1000;
  const totalDuration = daysBack * 24 * 60 * 60 * 1000;
  const startTime = now - totalDuration;

  let currentStart = startTime;

  while (currentStart < now) {
    const currentEnd = Math.min(currentStart + batchDuration, now);
    const start = new Date(currentStart).toISOString();
    const end = new Date(currentEnd).toISOString();

    try {
      let url = `${BASE_URL}/products/ETH-USDT/candles?granularity=${granularity}&start=${start}&end=${end}`;
      let res = await fetch(url, { headers: { 'Content-Type': 'application/json' } });

      if (!res.ok) {
        url = `${BASE_URL}/products/ETH-USD/candles?granularity=${granularity}&start=${start}&end=${end}`;
        res = await fetch(url, { headers: { 'Content-Type': 'application/json' } });
      }

      if (res.ok) {
        const data = await res.json();
        const candles = parseCandles(data);
        allCandles.push(...candles);
      }
    } catch (err: any) {
      console.error('Batch fetch error:', err?.message);
    }

    currentStart = currentEnd;
    // Rate limiting - wait 200ms between requests
    await new Promise((resolve) => setTimeout(resolve, 200));
  }

  // Remove duplicates by timestamp and sort
  const seen = new Set<number>();
  const unique = allCandles.filter((c: RawCandle) => {
    if (seen.has(c.timestamp)) return false;
    seen.add(c.timestamp);
    return true;
  });

  return unique.sort((a: RawCandle, b: RawCandle) => a.timestamp - b.timestamp);
}

// Fetch current ticker price
export async function fetchTicker(): Promise<{ price: number; volume24h: number; change24h: number } | null> {
  try {
    let res = await fetch(`${BASE_URL}/products/ETH-USDT/ticker`, {
      headers: { 'Content-Type': 'application/json' },
      next: { revalidate: 0 },
    });

    if (!res.ok) {
      res = await fetch(`${BASE_URL}/products/ETH-USD/ticker`, {
        headers: { 'Content-Type': 'application/json' },
        next: { revalidate: 0 },
      });
    }

    if (!res.ok) return null;
    const data = await res.json();

    let res24h = await fetch(`${BASE_URL}/products/ETH-USDT/stats`, {
      headers: { 'Content-Type': 'application/json' },
      next: { revalidate: 0 },
    });
    if (!res24h.ok) {
      res24h = await fetch(`${BASE_URL}/products/ETH-USD/stats`, {
        headers: { 'Content-Type': 'application/json' },
        next: { revalidate: 0 },
      });
    }
    const stats = res24h.ok ? await res24h.json() : {};

    const price = parseFloat(data?.price ?? '0');
    const openPrice = parseFloat(stats?.open ?? '0');
    const volume24h = parseFloat(stats?.volume ?? '0');
    const change24h = openPrice > 0 ? ((price - openPrice) / openPrice) * 100 : 0;

    return {
      price: Math.round(price * 100) / 100,
      volume24h: Math.round(volume24h * 100) / 100,
      change24h: Math.round(change24h * 100) / 100,
    };
  } catch (error: any) {
    console.error('Failed to fetch ticker:', error?.message);
    return null;
  }
}
