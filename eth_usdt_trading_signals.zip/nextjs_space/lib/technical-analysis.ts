// Technical Analysis Engine for ETH/USDT

export interface CandleData {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

// RSI Calculation
export function calculateRSI(closes: number[], period: number = 14): number[] {
  const rsi: number[] = [];
  if ((closes?.length ?? 0) < period + 1) return rsi;

  let gains = 0;
  let losses = 0;

  for (let i = 1; i <= period; i++) {
    const change = (closes?.[i] ?? 0) - (closes?.[i - 1] ?? 0);
    if (change >= 0) gains += change;
    else losses += Math.abs(change);
  }

  let avgGain = gains / period;
  let avgLoss = losses / period;
  const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
  rsi.push(100 - 100 / (1 + rs));

  for (let i = period + 1; i < (closes?.length ?? 0); i++) {
    const change = (closes?.[i] ?? 0) - (closes?.[i - 1] ?? 0);
    const gain = change >= 0 ? change : 0;
    const loss = change < 0 ? Math.abs(change) : 0;

    avgGain = (avgGain * (period - 1) + gain) / period;
    avgLoss = (avgLoss * (period - 1) + loss) / period;

    const newRs = avgLoss === 0 ? 100 : avgGain / avgLoss;
    rsi.push(100 - 100 / (1 + newRs));
  }

  return rsi;
}

// MACD Calculation
export function calculateMACD(
  closes: number[],
  fastPeriod: number = 12,
  slowPeriod: number = 26,
  signalPeriod: number = 9
): { macd: number[]; signal: number[]; histogram: number[] } {
  const emaFast = calculateEMA(closes, fastPeriod);
  const emaSlow = calculateEMA(closes, slowPeriod);

  const macdLine: number[] = [];
  const offset = slowPeriod - fastPeriod;

  for (let i = 0; i < (emaSlow?.length ?? 0); i++) {
    macdLine.push((emaFast?.[i + offset] ?? 0) - (emaSlow?.[i] ?? 0));
  }

  const signalLine = calculateEMA(macdLine, signalPeriod);
  const histogram: number[] = [];
  const sigOffset = (macdLine?.length ?? 0) - (signalLine?.length ?? 0);

  for (let i = 0; i < (signalLine?.length ?? 0); i++) {
    histogram.push((macdLine?.[i + sigOffset] ?? 0) - (signalLine?.[i] ?? 0));
  }

  return { macd: macdLine, signal: signalLine, histogram };
}

// EMA Calculation
export function calculateEMA(data: number[], period: number): number[] {
  const ema: number[] = [];
  if ((data?.length ?? 0) < period) return ema;

  let sum = 0;
  for (let i = 0; i < period; i++) {
    sum += data?.[i] ?? 0;
  }
  ema.push(sum / period);

  const multiplier = 2 / (period + 1);
  for (let i = period; i < (data?.length ?? 0); i++) {
    const val = ((data?.[i] ?? 0) - (ema?.[ema.length - 1] ?? 0)) * multiplier + (ema?.[ema.length - 1] ?? 0);
    ema.push(val);
  }

  return ema;
}

// SMA Calculation
export function calculateSMA(data: number[], period: number): number[] {
  const sma: number[] = [];
  if ((data?.length ?? 0) < period) return sma;
  for (let i = period - 1; i < (data?.length ?? 0); i++) {
    let sum = 0;
    for (let j = i - period + 1; j <= i; j++) {
      sum += data?.[j] ?? 0;
    }
    sma.push(sum / period);
  }
  return sma;
}

// Support & Resistance zones
export function findSupportResistance(candles: CandleData[], lookback: number = 50): { supports: number[]; resistances: number[] } {
  const supports: number[] = [];
  const resistances: number[] = [];
  const safeCandles = candles ?? [];
  const len = safeCandles.length;
  if (len < 5) return { supports, resistances };

  const start = Math.max(2, len - lookback);
  for (let i = start; i < len - 2; i++) {
    const c = safeCandles[i];
    const prev1 = safeCandles[i - 1];
    const prev2 = safeCandles[i - 2];
    const next1 = safeCandles[i + 1];
    const next2 = safeCandles[i + 2];
    if (!c || !prev1 || !prev2 || !next1 || !next2) continue;

    // Swing low = support
    if (c.low < prev1.low && c.low < prev2.low && c.low < next1.low && c.low < next2.low) {
      supports.push(c.low);
    }
    // Swing high = resistance
    if (c.high > prev1.high && c.high > prev2.high && c.high > next1.high && c.high > next2.high) {
      resistances.push(c.high);
    }
  }

  return {
    supports: clusterLevels(supports),
    resistances: clusterLevels(resistances),
  };
}

function clusterLevels(levels: number[], threshold: number = 0.005): number[] {
  if ((levels?.length ?? 0) === 0) return [];
  const sorted = [...levels].sort((a, b) => a - b);
  const clusters: number[][] = [[sorted[0]]];

  for (let i = 1; i < sorted.length; i++) {
    const lastCluster = clusters[clusters.length - 1];
    const lastAvg = lastCluster.reduce((s: number, v: number) => s + v, 0) / lastCluster.length;
    if (Math.abs(sorted[i] - lastAvg) / lastAvg < threshold) {
      lastCluster.push(sorted[i]);
    } else {
      clusters.push([sorted[i]]);
    }
  }

  return clusters.map((c: number[]) => c.reduce((s: number, v: number) => s + v, 0) / c.length);
}

// Candlestick pattern detection
export function detectCandlestickPatterns(candles: CandleData[]): string[] {
  const patterns: string[] = [];
  const len = candles?.length ?? 0;
  if (len < 3) return patterns;

  const last = candles?.[len - 1];
  const prev = candles?.[len - 2];
  const prevPrev = candles?.[len - 3];
  if (!last || !prev || !prevPrev) return patterns;

  const bodySize = Math.abs(last.close - last.open);
  const totalRange = last.high - last.low;
  const upperWick = last.high - Math.max(last.close, last.open);
  const lowerWick = Math.min(last.close, last.open) - last.low;

  // Doji
  if (totalRange > 0 && bodySize / totalRange < 0.1) {
    patterns.push('DOJI');
  }

  // Hammer (bullish)
  if (lowerWick > bodySize * 2 && upperWick < bodySize * 0.5 && last.close > last.open) {
    patterns.push('HAMMER');
  }

  // Shooting Star (bearish)
  if (upperWick > bodySize * 2 && lowerWick < bodySize * 0.5 && last.close < last.open) {
    patterns.push('SHOOTING_STAR');
  }

  // Bullish Engulfing
  if (
    prev.close < prev.open &&
    last.close > last.open &&
    last.open <= prev.close &&
    last.close >= prev.open
  ) {
    patterns.push('BULLISH_ENGULFING');
  }

  // Bearish Engulfing
  if (
    prev.close > prev.open &&
    last.close < last.open &&
    last.open >= prev.close &&
    last.close <= prev.open
  ) {
    patterns.push('BEARISH_ENGULFING');
  }

  // Morning Star (3 candle bullish reversal)
  if (
    prevPrev.close < prevPrev.open &&
    Math.abs(prev.close - prev.open) < Math.abs(prevPrev.close - prevPrev.open) * 0.3 &&
    last.close > last.open &&
    last.close > (prevPrev.open + prevPrev.close) / 2
  ) {
    patterns.push('MORNING_STAR');
  }

  // Evening Star (3 candle bearish reversal)
  if (
    prevPrev.close > prevPrev.open &&
    Math.abs(prev.close - prev.open) < Math.abs(prevPrev.close - prevPrev.open) * 0.3 &&
    last.close < last.open &&
    last.close < (prevPrev.open + prevPrev.close) / 2
  ) {
    patterns.push('EVENING_STAR');
  }

  return patterns;
}

// Trend detection
export function detectTrend(candles: CandleData[], period: number = 20): 'UPTREND' | 'DOWNTREND' | 'SIDEWAYS' {
  const safeCandles = candles ?? [];
  if (safeCandles.length < period) return 'SIDEWAYS';
  const recent = safeCandles.slice(-period);
  const closes = recent.map((c: CandleData) => c?.close ?? 0);
  const sma = calculateSMA(closes, period);
  if ((sma?.length ?? 0) === 0) return 'SIDEWAYS';

  const currentPrice = closes[closes.length - 1] ?? 0;
  const smaVal = sma[sma.length - 1] ?? 0;

  // Check higher highs / lower lows
  let higherHighs = 0;
  let lowerLows = 0;
  for (let i = Math.max(1, recent.length - 10); i < recent.length; i++) {
    if ((recent?.[i]?.high ?? 0) > (recent?.[i - 1]?.high ?? 0)) higherHighs++;
    if ((recent?.[i]?.low ?? 0) < (recent?.[i - 1]?.low ?? 0)) lowerLows++;
  }

  if (currentPrice > smaVal && higherHighs > lowerLows) return 'UPTREND';
  if (currentPrice < smaVal && lowerLows > higherHighs) return 'DOWNTREND';
  return 'SIDEWAYS';
}

// ATR (Average True Range) for stop loss calculation
export function calculateATR(candles: CandleData[], period: number = 14): number {
  const safeCandles = candles ?? [];
  if (safeCandles.length < period + 1) return 0;

  const trueRanges: number[] = [];
  for (let i = 1; i < safeCandles.length; i++) {
    const c = safeCandles[i];
    const p = safeCandles[i - 1];
    if (!c || !p) continue;
    const tr = Math.max(
      c.high - c.low,
      Math.abs(c.high - p.close),
      Math.abs(c.low - p.close)
    );
    trueRanges.push(tr);
  }

  const recentTR = trueRanges.slice(-period);
  return recentTR.reduce((s: number, v: number) => s + v, 0) / (recentTR?.length || 1);
}

// Generate Trading Signal
export interface TradingSignal {
  type: 'BUY' | 'SELL';
  entryPrice: number;
  stopLoss: number;
  target1: number;
  target2: number;
  target3: number;
  confidence: number;
  riskReward: number;
  reasoning: string;
  timeframe: string;
}

export function generateSignal(candles: CandleData[], timeframe: string = '1h'): TradingSignal | null {
  const safeCandles = candles ?? [];
  if (safeCandles.length < 50) return null;

  const closes = safeCandles.map((c: CandleData) => c?.close ?? 0);
  const currentPrice = closes[closes.length - 1] ?? 0;
  if (currentPrice === 0) return null;

  // Calculate indicators
  const rsiValues = calculateRSI(closes);
  const currentRSI = rsiValues?.[rsiValues.length - 1] ?? 50;
  const macdData = calculateMACD(closes);
  const currentMACD = macdData?.histogram?.[macdData.histogram.length - 1] ?? 0;
  const prevMACD = macdData?.histogram?.[macdData.histogram.length - 2] ?? 0;
  const trend = detectTrend(safeCandles);
  const patterns = detectCandlestickPatterns(safeCandles);
  const { supports, resistances } = findSupportResistance(safeCandles);
  const atr = calculateATR(safeCandles);

  if (atr === 0) return null;

  // Scoring system
  let bullScore = 0;
  let bearScore = 0;
  const reasons: string[] = [];

  // RSI signals
  if (currentRSI < 30) { bullScore += 2; reasons.push(`RSI oversold (${currentRSI.toFixed(1)})`); }
  else if (currentRSI < 40) { bullScore += 1; reasons.push(`RSI approaching oversold (${currentRSI.toFixed(1)})`); }
  else if (currentRSI > 70) { bearScore += 2; reasons.push(`RSI overbought (${currentRSI.toFixed(1)})`); }
  else if (currentRSI > 60) { bearScore += 1; reasons.push(`RSI approaching overbought (${currentRSI.toFixed(1)})`); }

  // MACD crossover
  if (currentMACD > 0 && prevMACD <= 0) { bullScore += 2; reasons.push('MACD bullish crossover'); }
  else if (currentMACD < 0 && prevMACD >= 0) { bearScore += 2; reasons.push('MACD bearish crossover'); }
  else if (currentMACD > prevMACD) { bullScore += 1; reasons.push('MACD momentum increasing'); }
  else if (currentMACD < prevMACD) { bearScore += 1; reasons.push('MACD momentum decreasing'); }

  // Trend
  if (trend === 'UPTREND') { bullScore += 2; reasons.push('Price in uptrend'); }
  else if (trend === 'DOWNTREND') { bearScore += 2; reasons.push('Price in downtrend'); }

  // Patterns
  const bullPatterns = ['HAMMER', 'BULLISH_ENGULFING', 'MORNING_STAR'];
  const bearPatterns = ['SHOOTING_STAR', 'BEARISH_ENGULFING', 'EVENING_STAR'];
  for (const p of patterns) {
    if (bullPatterns.includes(p)) { bullScore += 2; reasons.push(`Bullish pattern: ${p}`); }
    if (bearPatterns.includes(p)) { bearScore += 2; reasons.push(`Bearish pattern: ${p}`); }
    if (p === 'DOJI') { reasons.push('Indecision candle (Doji)'); }
  }

  // Support/Resistance proximity
  const nearSupport = supports.find((s: number) => Math.abs(currentPrice - s) / currentPrice < 0.01);
  const nearResistance = resistances.find((r: number) => Math.abs(currentPrice - r) / currentPrice < 0.01);
  if (nearSupport) { bullScore += 1; reasons.push(`Near support zone ($${nearSupport.toFixed(2)})`); }
  if (nearResistance) { bearScore += 1; reasons.push(`Near resistance zone ($${nearResistance.toFixed(2)})`); }

  const totalScore = bullScore + bearScore;
  if (totalScore < 3) return null; // Not enough confluence

  const isBuy = bullScore > bearScore;
  const confidence = Math.min(95, Math.round((Math.max(bullScore, bearScore) / Math.max(totalScore, 1)) * 100));

  if (confidence < 55) return null;

  const stopDistance = atr * 1.5;
  const stopLoss = isBuy ? currentPrice - stopDistance : currentPrice + stopDistance;
  const target1 = isBuy ? currentPrice + atr * 1.5 : currentPrice - atr * 1.5;
  const target2 = isBuy ? currentPrice + atr * 2.5 : currentPrice - atr * 2.5;
  const target3 = isBuy ? currentPrice + atr * 4 : currentPrice - atr * 4;

  const risk = Math.abs(currentPrice - stopLoss);
  const reward = Math.abs(target2 - currentPrice);
  const riskReward = risk > 0 ? Math.round((reward / risk) * 100) / 100 : 0;

  if (riskReward < 1.2) return null;

  return {
    type: isBuy ? 'BUY' : 'SELL',
    entryPrice: Math.round(currentPrice * 100) / 100,
    stopLoss: Math.round(stopLoss * 100) / 100,
    target1: Math.round(target1 * 100) / 100,
    target2: Math.round(target2 * 100) / 100,
    target3: Math.round(target3 * 100) / 100,
    confidence,
    riskReward,
    reasoning: reasons.join(' | '),
    timeframe,
  };
}

// Backtest engine
export interface BacktestTrade {
  entryDate: string;
  exitDate: string;
  type: 'BUY' | 'SELL';
  entryPrice: number;
  exitPrice: number;
  pnlPercent: number;
  outcome: string;
}

export interface BacktestResults {
  totalTrades: number;
  winRate: number;
  avgProfitPct: number;
  avgLossPct: number;
  maxDrawdownPct: number;
  totalReturnPct: number;
  sharpeRatio: number;
  profitFactor: number;
  equityCurve: { date: string; equity: number }[];
  trades: BacktestTrade[];
}

export function runBacktest(candles: CandleData[]): BacktestResults {
  const safeCandles = candles ?? [];
  const trades: BacktestTrade[] = [];
  let equity = 10000;
  const equityCurve: { date: string; equity: number }[] = [{ date: new Date(safeCandles?.[0]?.timestamp ?? 0).toISOString().split('T')[0], equity }];
  let peakEquity = equity;
  let maxDrawdown = 0;

  const windowSize = 100;
  const stepSize = 24; // Skip 24 candles between signal checks

  for (let i = windowSize; i < safeCandles.length - 50; i += stepSize) {
    const window = safeCandles.slice(i - windowSize, i);
    const signal = generateSignal(window, '1h');

    if (!signal) continue;

    // Simulate trade: look forward to see outcome
    const entryPrice = signal.entryPrice;
    let exitPrice = entryPrice;
    let outcome = 'EXPIRED';

    for (let j = i; j < Math.min(i + 48, safeCandles.length); j++) {
      const candle = safeCandles[j];
      if (!candle) continue;

      if (signal.type === 'BUY') {
        if (candle.low <= signal.stopLoss) {
          exitPrice = signal.stopLoss;
          outcome = 'STOPPED_OUT';
          break;
        }
        if (candle.high >= signal.target3) {
          exitPrice = signal.target3;
          outcome = 'TP3_HIT';
          break;
        }
        if (candle.high >= signal.target2) {
          exitPrice = signal.target2;
          outcome = 'TP2_HIT';
          break;
        }
        if (candle.high >= signal.target1) {
          exitPrice = signal.target1;
          outcome = 'TP1_HIT';
          break;
        }
      } else {
        if (candle.high >= signal.stopLoss) {
          exitPrice = signal.stopLoss;
          outcome = 'STOPPED_OUT';
          break;
        }
        if (candle.low <= signal.target3) {
          exitPrice = signal.target3;
          outcome = 'TP3_HIT';
          break;
        }
        if (candle.low <= signal.target2) {
          exitPrice = signal.target2;
          outcome = 'TP2_HIT';
          break;
        }
        if (candle.low <= signal.target1) {
          exitPrice = signal.target1;
          outcome = 'TP1_HIT';
          break;
        }
      }
    }

    if (outcome === 'EXPIRED') {
      exitPrice = safeCandles?.[Math.min(i + 48, safeCandles.length - 1)]?.close ?? entryPrice;
    }

    const pnlPct = signal.type === 'BUY'
      ? ((exitPrice - entryPrice) / entryPrice) * 100
      : ((entryPrice - exitPrice) / entryPrice) * 100;

    equity *= (1 + pnlPct / 100);
    if (equity > peakEquity) peakEquity = equity;
    const drawdown = ((peakEquity - equity) / peakEquity) * 100;
    if (drawdown > maxDrawdown) maxDrawdown = drawdown;

    const entryDate = new Date((safeCandles?.[i]?.timestamp ?? 0)).toISOString().split('T')[0];
    equityCurve.push({ date: entryDate, equity: Math.round(equity * 100) / 100 });

    trades.push({
      entryDate,
      exitDate: entryDate,
      type: signal.type,
      entryPrice,
      exitPrice: Math.round(exitPrice * 100) / 100,
      pnlPercent: Math.round(pnlPct * 100) / 100,
      outcome,
    });
  }

  const wins = trades.filter((t: BacktestTrade) => t.pnlPercent > 0);
  const losses = trades.filter((t: BacktestTrade) => t.pnlPercent <= 0);
  const avgProfit = wins.length > 0 ? wins.reduce((s: number, t: BacktestTrade) => s + t.pnlPercent, 0) / wins.length : 0;
  const avgLoss = losses.length > 0 ? losses.reduce((s: number, t: BacktestTrade) => s + Math.abs(t.pnlPercent), 0) / losses.length : 0;
  const totalGross = wins.reduce((s: number, t: BacktestTrade) => s + t.pnlPercent, 0);
  const totalLoss = losses.reduce((s: number, t: BacktestTrade) => s + Math.abs(t.pnlPercent), 0);

  const returns = trades.map((t: BacktestTrade) => t.pnlPercent);
  const meanReturn = returns.length > 0 ? returns.reduce((s: number, v: number) => s + v, 0) / returns.length : 0;
  const variance = returns.length > 1 ? returns.reduce((s: number, v: number) => s + Math.pow(v - meanReturn, 2), 0) / (returns.length - 1) : 0;
  const stdDev = Math.sqrt(variance);
  const sharpe = stdDev > 0 ? (meanReturn / stdDev) * Math.sqrt(252) : 0;

  return {
    totalTrades: trades.length,
    winRate: trades.length > 0 ? Math.round((wins.length / trades.length) * 10000) / 100 : 0,
    avgProfitPct: Math.round(avgProfit * 100) / 100,
    avgLossPct: Math.round(avgLoss * 100) / 100,
    maxDrawdownPct: Math.round(maxDrawdown * 100) / 100,
    totalReturnPct: Math.round(((equity - 10000) / 10000) * 10000) / 100,
    sharpeRatio: Math.round(sharpe * 100) / 100,
    profitFactor: totalLoss > 0 ? Math.round((totalGross / totalLoss) * 100) / 100 : totalGross > 0 ? 999 : 0,
    equityCurve,
    trades,
  };
}
