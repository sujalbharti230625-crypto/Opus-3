export const dynamic = "force-dynamic";

import { NextResponse } from 'next/server';
import { fetchTicker } from '@/lib/coinbase';

export async function GET() {
  try {
    const ticker = await fetchTicker();
    if (!ticker) {
      return NextResponse.json({ error: 'Failed to fetch ticker' }, { status: 500 });
    }
    return NextResponse.json(ticker);
  } catch (error: any) {
    console.error('Ticker API error:', error?.message);
    return NextResponse.json({ error: 'Failed to fetch ticker' }, { status: 500 });
  }
}
