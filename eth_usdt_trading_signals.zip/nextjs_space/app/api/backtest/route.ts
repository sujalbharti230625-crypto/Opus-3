export const dynamic = "force-dynamic";

import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { fetchHistoricalCandles } from '@/lib/coinbase';
import { runBacktest } from '@/lib/technical-analysis';
import type { CandleData } from '@/lib/technical-analysis';

export async function GET() {
  try {
    const results = await prisma.backtestResult.findMany({
      orderBy: { createdAt: 'desc' },
      take: 1,
    });

    if ((results?.length ?? 0) === 0) {
      return NextResponse.json({ result: null });
    }

    const r = results[0];
    return NextResponse.json({
      result: {
        ...r,
        equityCurve: JSON.parse(r?.equityCurve ?? '[]'),
        tradesData: JSON.parse(r?.tradesData ?? '[]'),
      },
    });
  } catch (error: any) {
    console.error('Backtest GET error:', error?.message);
    return NextResponse.json({ result: null, error: 'Failed to fetch backtest results' }, { status: 500 });
  }
}

export async function POST() {
  try {
    // Fetch historical data (last 6 months for reasonable speed)
    const rawCandles = await fetchHistoricalCandles('1h', 180);

    if ((rawCandles?.length ?? 0) < 200) {
      return NextResponse.json({ error: 'Insufficient historical data' }, { status: 400 });
    }

    const candles: CandleData[] = rawCandles.map((c: any) => ({
      timestamp: c?.timestamp ?? 0,
      open: c?.open ?? 0,
      high: c?.high ?? 0,
      low: c?.low ?? 0,
      close: c?.close ?? 0,
      volume: c?.volume ?? 0,
    }));

    const results = runBacktest(candles);

    const saved = await prisma.backtestResult.create({
      data: {
        startDate: new Date(candles?.[0]?.timestamp ?? 0),
        endDate: new Date(candles?.[candles.length - 1]?.timestamp ?? 0),
        totalTrades: results.totalTrades,
        winRate: results.winRate,
        avgProfitPct: results.avgProfitPct,
        avgLossPct: results.avgLossPct,
        maxDrawdownPct: results.maxDrawdownPct,
        totalReturnPct: results.totalReturnPct,
        sharpeRatio: results.sharpeRatio,
        profitFactor: results.profitFactor,
        equityCurve: JSON.stringify(results.equityCurve),
        tradesData: JSON.stringify(results.trades),
      },
    });

    return NextResponse.json({
      result: {
        ...saved,
        equityCurve: results.equityCurve,
        tradesData: results.trades,
      },
    });
  } catch (error: any) {
    console.error('Backtest run error:', error?.message);
    return NextResponse.json({ error: 'Failed to run backtest' }, { status: 500 });
  }
}
