export const dynamic = "force-dynamic";

import { NextResponse } from 'next/server';
import { fetchCandles } from '@/lib/coinbase';
import { calculateRSI, calculateMACD, calculateSMA, findSupportResistance, detectTrend, detectCandlestickPatterns } from '@/lib/technical-analysis';
import type { CandleData } from '@/lib/technical-analysis';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const timeframe = searchParams.get('timeframe') ?? '1h';
    const withIndicators = searchParams.get('indicators') === 'true';

    const rawCandles = await fetchCandles(timeframe, 300);

    if ((rawCandles?.length ?? 0) === 0) {
      return NextResponse.json({ candles: [], indicators: null });
    }

    const candles = rawCandles.map((c: any) => ({
      timestamp: c?.timestamp ?? 0,
      open: c?.open ?? 0,
      high: c?.high ?? 0,
      low: c?.low ?? 0,
      close: c?.close ?? 0,
      volume: c?.volume ?? 0,
    }));

    let indicators = null;
    if (withIndicators) {
      const closes = candles.map((c: any) => c?.close ?? 0);
      const rsi = calculateRSI(closes);
      const macd = calculateMACD(closes);
      const sma20 = calculateSMA(closes, 20);
      const sma50 = calculateSMA(closes, 50);
      const candleData: CandleData[] = candles;
      const sr = findSupportResistance(candleData);
      const trend = detectTrend(candleData);
      const patterns = detectCandlestickPatterns(candleData);

      indicators = {
        rsi: rsi.slice(-50),
        macd: {
          macd: macd.macd.slice(-50),
          signal: macd.signal.slice(-50),
          histogram: macd.histogram.slice(-50),
        },
        sma20: sma20.slice(-50),
        sma50: sma50.slice(-50),
        supports: sr.supports,
        resistances: sr.resistances,
        trend,
        patterns,
      };
    }

    return NextResponse.json({
      candles: candles.slice(-200),
      indicators,
    });
  } catch (error: any) {
    console.error('Candles API error:', error?.message);
    return NextResponse.json({ candles: [], indicators: null, error: 'Failed to fetch data' }, { status: 500 });
  }
}
