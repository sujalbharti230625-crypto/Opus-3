export const dynamic = "force-dynamic";

import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { fetchCandles } from '@/lib/coinbase';
import { generateSignal } from '@/lib/technical-analysis';
import type { CandleData } from '@/lib/technical-analysis';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const limit = parseInt(searchParams.get('limit') ?? '20', 10);

    const where = status ? { status } : {};
    const signals = await prisma.signal.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: Math.min(limit, 100),
    });

    return NextResponse.json({ signals });
  } catch (error: any) {
    console.error('Signals GET error:', error?.message);
    return NextResponse.json({ signals: [], error: 'Failed to fetch signals' }, { status: 500 });
  }
}

export async function POST() {
  try {
    // Generate signals for multiple timeframes
    const timeframes = ['1h', '4h', '1d'];
    const newSignals: any[] = [];

    for (const tf of timeframes) {
      const rawCandles = await fetchCandles(tf, 200);
      if ((rawCandles?.length ?? 0) < 50) continue;

      const candles: CandleData[] = rawCandles.map((c: any) => ({
        timestamp: c?.timestamp ?? 0,
        open: c?.open ?? 0,
        high: c?.high ?? 0,
        low: c?.low ?? 0,
        close: c?.close ?? 0,
        volume: c?.volume ?? 0,
      }));

      const signal = generateSignal(candles, tf);
      if (signal) {
        // Check for recent duplicate
        const recentSignal = await prisma.signal.findFirst({
          where: {
            timeframe: tf,
            type: signal.type,
            createdAt: {
              gte: new Date(Date.now() - 3600000), // Within last hour
            },
          },
        });

        if (!recentSignal) {
          const created = await prisma.signal.create({
            data: {
              type: signal.type,
              entryPrice: signal.entryPrice,
              stopLoss: signal.stopLoss,
              target1: signal.target1,
              target2: signal.target2,
              target3: signal.target3,
              confidence: signal.confidence,
              riskReward: signal.riskReward,
              reasoning: signal.reasoning,
              timeframe: signal.timeframe,
              status: 'ACTIVE',
            },
          });
          newSignals.push(created);
        }
      }
    }

    // Update existing active signals
    await updateSignalStatuses();

    return NextResponse.json({ newSignals, message: `Generated ${newSignals.length} new signals` });
  } catch (error: any) {
    console.error('Signal generation error:', error?.message);
    return NextResponse.json({ error: 'Failed to generate signals' }, { status: 500 });
  }
}

async function updateSignalStatuses() {
  try {
    const activeSignals = await prisma.signal.findMany({
      where: { status: 'ACTIVE' },
    });

    const rawCandles = await fetchCandles('1h', 50);
    if ((rawCandles?.length ?? 0) === 0) return;

    const currentPrice = rawCandles?.[rawCandles.length - 1]?.close ?? 0;
    if (currentPrice === 0) return;

    for (const signal of activeSignals) {
      let newStatus = 'ACTIVE';
      let pnl = 0;

      if (signal.type === 'BUY') {
        if (currentPrice <= signal.stopLoss) {
          newStatus = 'STOPPED_OUT';
          pnl = ((signal.stopLoss - signal.entryPrice) / signal.entryPrice) * 100;
        } else if (currentPrice >= signal.target3) {
          newStatus = 'TP3_HIT';
          pnl = ((signal.target3 - signal.entryPrice) / signal.entryPrice) * 100;
        } else if (currentPrice >= signal.target2) {
          newStatus = 'TP2_HIT';
          pnl = ((signal.target2 - signal.entryPrice) / signal.entryPrice) * 100;
        } else if (currentPrice >= signal.target1) {
          newStatus = 'TP1_HIT';
          pnl = ((signal.target1 - signal.entryPrice) / signal.entryPrice) * 100;
        }
      } else {
        if (currentPrice >= signal.stopLoss) {
          newStatus = 'STOPPED_OUT';
          pnl = ((signal.entryPrice - signal.stopLoss) / signal.entryPrice) * 100;
        } else if (currentPrice <= signal.target3) {
          newStatus = 'TP3_HIT';
          pnl = ((signal.entryPrice - signal.target3) / signal.entryPrice) * 100;
        } else if (currentPrice <= signal.target2) {
          newStatus = 'TP2_HIT';
          pnl = ((signal.entryPrice - signal.target2) / signal.entryPrice) * 100;
        } else if (currentPrice <= signal.target1) {
          newStatus = 'TP1_HIT';
          pnl = ((signal.entryPrice - signal.target1) / signal.entryPrice) * 100;
        }
      }

      // Expire signals older than 48 hours
      const age = Date.now() - new Date(signal.createdAt).getTime();
      if (newStatus === 'ACTIVE' && age > 48 * 3600 * 1000) {
        newStatus = 'EXPIRED';
        pnl = signal.type === 'BUY'
          ? ((currentPrice - signal.entryPrice) / signal.entryPrice) * 100
          : ((signal.entryPrice - currentPrice) / signal.entryPrice) * 100;
      }

      if (newStatus !== 'ACTIVE') {
        await prisma.signal.update({
          where: { id: signal.id },
          data: {
            status: newStatus,
            pnlPercent: Math.round(pnl * 100) / 100,
            closedAt: new Date(),
            outcome: newStatus === 'STOPPED_OUT'
              ? `Stopped out at $${signal.stopLoss}`
              : newStatus === 'EXPIRED'
                ? `Expired at $${currentPrice.toFixed(2)}`
                : `${newStatus.replace('_', ' ')} at target price`,
          },
        });
      }
    }
  } catch (error: any) {
    console.error('Update signal status error:', error?.message);
  }
}
