import Header from './components/header';
import DashboardClient from './components/dashboard-client';

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="mx-auto max-w-[1200px] px-4 py-6">
        <div className="mb-6">
          <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight">
            ETH/USDT <span className="text-primary">Trading Signals</span>
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Real-time technical analysis with multi-timeframe signal generation
          </p>
        </div>
        <DashboardClient />
      </main>
    </div>
  );
}
