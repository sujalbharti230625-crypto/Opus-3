'use client';

import { useState, useEffect, useCallback } from 'react';
import { BarChart3, Play, RefreshCw, TrendingUp, TrendingDown, Target, Shield, Clock, Award, Percent, ArrowUpCircle, ArrowDownCircle } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, Cell, PieChart, Pie } from 'recharts';
import { motion } from 'framer-motion';
import { toast } from 'sonner';

export default function BacktestClient() {
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [running, setRunning] = useState(false);

  const fetchResults = useCallback(async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/backtest');
      if (res.ok) {
        const data = await res.json();
        setResult(data?.result ?? null);
      }
    } catch (e: any) {
      console.error('Backtest fetch error:', e?.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchResults();
  }, [fetchResults]);

  const runBacktest = async () => {
    try {
      setRunning(true);
      toast.info('Fetching historical data and running backtest... This may take a minute.');
      const res = await fetch('/api/backtest', { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        setResult(data?.result ?? null);
        toast.success('Backtest completed successfully!');
      } else {
        const errData = await res.json().catch(() => ({}));
        toast.error(errData?.error ?? 'Backtest failed');
      }
    } catch (e: any) {
      console.error('Backtest run error:', e?.message);
      toast.error('Failed to run backtest');
    } finally {
      setRunning(false);
    }
  };

  const trades = result?.tradesData ?? [];
  const equityCurve = result?.equityCurve ?? [];

  // Outcome distribution
  const outcomes: Record<string, number> = {};
  for (const t of trades) {
    const key = t?.outcome ?? 'UNKNOWN';
    outcomes[key] = (outcomes[key] ?? 0) + 1;
  }
  const outcomeData = Object.entries(outcomes ?? {}).map(([name, value]: [string, number]) => ({ name: name?.replace?.(/_/g, ' ') ?? '', value }));
  const outcomeColors = ['#10b981', '#22c55e', '#4ade80', '#ef4444', '#f59e0b', '#60B5FF'];

  // PnL distribution
  const pnlData = (trades ?? []).map((t: any, i: number) => ({
    index: i,
    pnl: t?.pnlPercent ?? 0,
  }));

  return (
    <div className="space-y-6">
      {/* Run Backtest Button */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 rounded-xl bg-card border border-border/50 p-5"
      >
        <div>
          <h2 className="font-display text-lg font-bold flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-primary" />
            Historical Backtest
          </h2>
          <p className="text-sm text-muted-foreground mt-0.5">Run the trading algorithm against ~6 months of hourly ETH/USDT data</p>
        </div>
        <button
          onClick={runBacktest}
          disabled={running}
          className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 disabled:opacity-50 transition-all"
        >
          {running ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
          {running ? 'Running Backtest...' : 'Run Backtest'}
        </button>
      </motion.div>

      {loading ? (
        <div className="space-y-4">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            {[1, 2, 3, 4].map((i: number) => (
              <div key={i} className="h-24 rounded-xl bg-card border border-border/50 animate-pulse" />
            ))}
          </div>
          <div className="h-64 rounded-xl bg-card border border-border/50 animate-pulse" />
        </div>
      ) : result ? (
        <>
          {/* Metrics Grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <MetricCard icon={<Target className="h-4 w-4" />} label="Total Trades" value={`${result?.totalTrades ?? 0}`} delay={0} />
            <MetricCard
              icon={<Award className="h-4 w-4" />}
              label="Win Rate"
              value={`${result?.winRate?.toFixed?.(1) ?? '0'}%`}
              positive={(result?.winRate ?? 0) > 50}
              delay={0.05}
            />
            <MetricCard
              icon={<TrendingUp className="h-4 w-4" />}
              label="Total Return"
              value={`${(result?.totalReturnPct ?? 0) >= 0 ? '+' : ''}${result?.totalReturnPct?.toFixed?.(2) ?? '0'}%`}
              positive={(result?.totalReturnPct ?? 0) >= 0}
              delay={0.1}
            />
            <MetricCard
              icon={<TrendingDown className="h-4 w-4" />}
              label="Max Drawdown"
              value={`-${result?.maxDrawdownPct?.toFixed?.(2) ?? '0'}%`}
              positive={false}
              delay={0.15}
            />
            <MetricCard icon={<Percent className="h-4 w-4" />} label="Avg Profit" value={`+${result?.avgProfitPct?.toFixed?.(2) ?? '0'}%`} positive delay={0.2} />
            <MetricCard icon={<Percent className="h-4 w-4" />} label="Avg Loss" value={`-${result?.avgLossPct?.toFixed?.(2) ?? '0'}%`} positive={false} delay={0.25} />
            <MetricCard icon={<Shield className="h-4 w-4" />} label="Profit Factor" value={`${result?.profitFactor?.toFixed?.(2) ?? '0'}`} delay={0.3} />
            <MetricCard icon={<BarChart3 className="h-4 w-4" />} label="Sharpe Ratio" value={`${result?.sharpeRatio?.toFixed?.(2) ?? '0'}`} delay={0.35} />
          </div>

          {/* Equity Curve */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="rounded-xl bg-card border border-border/50 p-4"
          >
            <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" />
              Equity Curve
            </h3>
            <div className="h-[280px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={equityCurve} margin={{ top: 5, right: 5, left: 5, bottom: 5 }}>
                  <defs>
                    <linearGradient id="eqGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#10b981" stopOpacity={0.3} />
                      <stop offset="100%" stopColor="#10b981" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="date" tickLine={false} tick={{ fontSize: 10 }} axisLine={false} interval="preserveStartEnd" minTickGap={60} />
                  <YAxis tickLine={false} tick={{ fontSize: 10 }} axisLine={false} width={55} tickFormatter={(v: number) => `$${(v ?? 0) >= 1000 ? `${((v ?? 0) / 1000).toFixed(1)}K` : v?.toFixed?.(0) ?? '0'}`} />
                  <Tooltip
                    contentStyle={{ backgroundColor: 'hsl(222 47% 8%)', border: '1px solid hsl(222 30% 16%)', borderRadius: '8px', fontSize: 11, color: 'hsl(210 40% 96%)' }}
                    formatter={(value: any) => [`$${Number(value)?.toFixed?.(2) ?? '0'}`, 'Equity']}
                  />
                  <Area type="monotone" dataKey="equity" stroke="#10b981" strokeWidth={2} fill="url(#eqGradient)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </motion.div>

          {/* PnL Distribution & Outcome Pie */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="rounded-xl bg-card border border-border/50 p-4"
            >
              <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                <BarChart3 className="h-4 w-4 text-primary" />
                PnL Distribution
              </h3>
              <div className="h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={pnlData} margin={{ top: 5, right: 5, left: 5, bottom: 5 }}>
                    <XAxis dataKey="index" hide />
                    <YAxis tickLine={false} tick={{ fontSize: 10 }} axisLine={false} width={40} tickFormatter={(v: number) => `${v?.toFixed?.(1) ?? '0'}%`} />
                    <Tooltip
                      contentStyle={{ backgroundColor: 'hsl(222 47% 8%)', border: '1px solid hsl(222 30% 16%)', borderRadius: '8px', fontSize: 11, color: 'hsl(210 40% 96%)' }}
                      formatter={(value: any) => [`${Number(value)?.toFixed?.(2) ?? '0'}%`, 'PnL']}
                    />
                    <Bar dataKey="pnl" name="PnL">
                      {(pnlData ?? []).map((entry: any, index: number) => (
                        <Cell key={index} fill={(entry?.pnl ?? 0) >= 0 ? '#10b981' : '#ef4444'} opacity={0.8} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.35 }}
              className="rounded-xl bg-card border border-border/50 p-4"
            >
              <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                <Target className="h-4 w-4 text-primary" />
                Outcome Distribution
              </h3>
              <div className="h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={outcomeData}
                      cx="50%"
                      cy="50%"
                      innerRadius={40}
                      outerRadius={70}
                      paddingAngle={3}
                      dataKey="value"
                      label={({ name, value }: any) => `${name ?? ''}: ${value ?? 0}`}
                    >
                      {(outcomeData ?? []).map((entry: any, index: number) => (
                        <Cell key={index} fill={outcomeColors[index % outcomeColors.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{ backgroundColor: 'hsl(222 47% 8%)', border: '1px solid hsl(222 30% 16%)', borderRadius: '8px', fontSize: 11, color: 'hsl(210 40% 96%)' }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </motion.div>
          </div>

          {/* Trades Table */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="rounded-xl bg-card border border-border/50 overflow-hidden"
          >
            <div className="p-4 border-b border-border/50">
              <h3 className="text-sm font-semibold flex items-center gap-2">
                <Clock className="h-4 w-4 text-primary" />
                Trade History ({trades?.length ?? 0} trades)
              </h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs font-mono">
                <thead>
                  <tr className="border-b border-border/50 text-muted-foreground">
                    <th className="text-left p-3">#</th>
                    <th className="text-left p-3">Date</th>
                    <th className="text-left p-3">Type</th>
                    <th className="text-right p-3">Entry</th>
                    <th className="text-right p-3">Exit</th>
                    <th className="text-right p-3">PnL</th>
                    <th className="text-left p-3">Outcome</th>
                  </tr>
                </thead>
                <tbody>
                  {(trades ?? []).slice(0, 50).map((t: any, i: number) => (
                    <tr key={i} className="border-b border-border/30 hover:bg-secondary/30 transition-colors">
                      <td className="p-3 text-muted-foreground">{i + 1}</td>
                      <td className="p-3">{t?.entryDate ?? '-'}</td>
                      <td className="p-3">
                        <span className={`flex items-center gap-1 ${t?.type === 'BUY' ? 'text-emerald-400' : 'text-red-400'}`}>
                          {t?.type === 'BUY' ? <ArrowUpCircle className="h-3 w-3" /> : <ArrowDownCircle className="h-3 w-3" />}
                          {t?.type ?? '-'}
                        </span>
                      </td>
                      <td className="p-3 text-right">${t?.entryPrice?.toFixed?.(2) ?? '0'}</td>
                      <td className="p-3 text-right">${t?.exitPrice?.toFixed?.(2) ?? '0'}</td>
                      <td className={`p-3 text-right font-bold ${(t?.pnlPercent ?? 0) >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                        {(t?.pnlPercent ?? 0) >= 0 ? '+' : ''}{t?.pnlPercent?.toFixed?.(2) ?? '0'}%
                      </td>
                      <td className="p-3">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                          t?.outcome?.includes?.('TP') ? 'bg-emerald-500/15 text-emerald-400' :
                          t?.outcome === 'STOPPED_OUT' ? 'bg-red-500/15 text-red-400' :
                          'bg-yellow-500/15 text-yellow-400'
                        }`}>
                          {t?.outcome?.replace?.(/_/g, ' ') ?? '-'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </motion.div>
        </>
      ) : (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="rounded-xl bg-card border border-border/50 p-12 text-center"
        >
          <BarChart3 className="h-10 w-10 text-muted-foreground/30 mx-auto mb-3" />
          <p className="text-muted-foreground mb-1">No backtest results yet.</p>
          <p className="text-xs text-muted-foreground">Click &quot;Run Backtest&quot; to analyze the strategy against historical data.</p>
        </motion.div>
      )}
    </div>
  );
}

function MetricCard({ icon, label, value, positive, delay = 0 }: {
  icon: React.ReactNode;
  label: string;
  value: string;
  positive?: boolean;
  delay?: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay }}
      className="rounded-xl bg-card border border-border/50 p-4 hover:border-primary/30 transition-all"
    >
      <div className="flex items-center gap-2 mb-1.5">
        <div className="text-primary">{icon}</div>
        <span className="text-xs text-muted-foreground">{label}</span>
      </div>
      <span className={`font-mono text-lg font-bold ${
        positive === true ? 'text-emerald-400' : positive === false ? 'text-red-400' : ''
      }`}>
        {value}
      </span>
    </motion.div>
  );
}
