import Header from '../components/header';
import BacktestClient from './backtest-client';

export default function BacktestPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="mx-auto max-w-[1200px] px-4 py-6">
        <div className="mb-6">
          <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight">
            Strategy <span className="text-primary">Backtesting</span>
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Test the signal generation algorithm against historical ETH/USDT data
          </p>
        </div>
        <BacktestClient />
      </main>
    </div>
  );
}
