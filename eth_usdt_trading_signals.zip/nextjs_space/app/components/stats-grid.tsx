'use client';

import { useEffect, useState, useRef } from 'react';
import { TrendingUp, TrendingDown, BarChart3, Zap, Target, Clock } from 'lucide-react';
import { motion } from 'framer-motion';

interface StatsProps {
  ticker: { price: number; change24h: number; volume24h: number } | null;
  signalCount: number;
  activeSignals: number;
  winRate: number;
}

export default function StatsGrid({ ticker, signalCount, activeSignals, winRate }: StatsProps) {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
      <StatCard
        icon={<TrendingUp className="h-4 w-4" />}
        label="ETH/USDT Price"
        value={`$${(ticker?.price ?? 0) > 0 ? (ticker?.price ?? 0).toLocaleString('en-US', { minimumFractionDigits: 2 }) : '---'}`}
        change={ticker?.change24h ?? 0}
        delay={0}
      />
      <StatCard
        icon={<BarChart3 className="h-4 w-4" />}
        label="24H Volume"
        value={`${(ticker?.volume24h ?? 0) > 0 ? formatVolume(ticker?.volume24h ?? 0) : '---'}`}
        delay={0.05}
      />
      <StatCard
        icon={<Zap className="h-4 w-4" />}
        label="Active Signals"
        value={`${activeSignals}`}
        subtitle={`${signalCount} total`}
        delay={0.1}
      />
      <StatCard
        icon={<Target className="h-4 w-4" />}
        label="Win Rate"
        value={`${winRate > 0 ? winRate.toFixed(1) : '---'}%`}
        delay={0.15}
      />
    </div>
  );
}

function StatCard({ icon, label, value, change, subtitle, delay = 0 }: {
  icon: React.ReactNode;
  label: string;
  value: string;
  change?: number;
  subtitle?: string;
  delay?: number;
}) {
  const isPositive = (change ?? 0) >= 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay }}
      className="rounded-xl bg-card border border-border/50 p-4 hover:border-primary/30 transition-all group"
    >
      <div className="flex items-center gap-2 mb-2">
        <div className="text-primary group-hover:scale-110 transition-transform">{icon}</div>
        <span className="text-xs text-muted-foreground">{label}</span>
      </div>
      <div className="flex items-end gap-2">
        <span className="font-mono text-lg font-bold tracking-tight">{value}</span>
        {change != null && (
          <span className={`text-xs font-mono font-medium mb-0.5 ${isPositive ? 'text-emerald-400' : 'text-red-400'}`}>
            {isPositive ? '+' : ''}{change?.toFixed?.(2) ?? '0'}%
          </span>
        )}
        {subtitle && (
          <span className="text-xs text-muted-foreground mb-0.5">{subtitle}</span>
        )}
      </div>
    </motion.div>
  );
}

function formatVolume(vol: number): string {
  if (vol >= 1000000) return `${(vol / 1000000).toFixed(1)}M ETH`;
  if (vol >= 1000) return `${(vol / 1000).toFixed(1)}K ETH`;
  return `${vol?.toFixed?.(1) ?? '0'} ETH`;
}
