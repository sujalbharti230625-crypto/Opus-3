'use client';

import { useState, useEffect } from 'react';
import { Activity, BarChart3, Clock, TrendingUp, Zap, Menu, X } from 'lucide-react';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';

export default function Header() {
  const [ticker, setTicker] = useState<{ price: number; change24h: number; volume24h: number } | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const fetchTicker = async () => {
      try {
        const res = await fetch('/api/ticker');
        if (res.ok) {
          const data = await res.json();
          setTicker(data);
        }
      } catch (e: any) {
        console.error('Ticker fetch error:', e?.message);
      }
    };
    fetchTicker();
    const interval = setInterval(fetchTicker, 15000);
    return () => clearInterval(interval);
  }, []);

  const price = ticker?.price ?? 0;
  const change = ticker?.change24h ?? 0;
  const isPositive = change >= 0;

  return (
    <header className="sticky top-0 z-50 border-b border-border/50 bg-background/80 backdrop-blur-xl">
      <div className="mx-auto max-w-[1200px] px-4">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/15 group-hover:bg-primary/25 transition-colors">
              <Zap className="h-5 w-5 text-primary" />
            </div>
            <div className="hidden sm:block">
              <span className="font-display text-lg font-bold tracking-tight">ETH/USDT</span>
              <span className="ml-1 text-xs text-muted-foreground">Signals</span>
            </div>
          </Link>

          {/* Price Ticker */}
          <div className="hidden md:flex items-center gap-3 font-mono text-sm">
            <div className="flex items-center gap-1.5">
              <Activity className="h-3.5 w-3.5 text-primary" />
              <span className="font-semibold">${price > 0 ? price.toLocaleString('en-US', { minimumFractionDigits: 2 }) : '---'}</span>
            </div>
            {price > 0 && (
              <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${isPositive ? 'bg-emerald-500/15 text-emerald-400' : 'bg-red-500/15 text-red-400'}`}>
                {isPositive ? '+' : ''}{change.toFixed(2)}%
              </span>
            )}
          </div>

          {/* Navigation */}
          <nav className="hidden md:flex items-center gap-1">
            <NavLink href="/" icon={<TrendingUp className="h-4 w-4" />} label="Dashboard" />
            <NavLink href="/signals" icon={<Zap className="h-4 w-4" />} label="Signals" />
            <NavLink href="/backtest" icon={<BarChart3 className="h-4 w-4" />} label="Backtest" />
            <NavLink href="/history" icon={<Clock className="h-4 w-4" />} label="History" />
          </nav>

          {/* Mobile menu button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-secondary transition-colors"
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden border-t border-border/50 bg-background/95 backdrop-blur-xl"
          >
            <div className="px-4 py-3 space-y-1">
              {/* Mobile ticker */}
              <div className="flex items-center gap-2 font-mono text-sm pb-3 border-b border-border/50 mb-2">
                <Activity className="h-3.5 w-3.5 text-primary" />
                <span className="font-semibold">${price > 0 ? price.toLocaleString('en-US', { minimumFractionDigits: 2 }) : '---'}</span>
                {price > 0 && (
                  <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${isPositive ? 'bg-emerald-500/15 text-emerald-400' : 'bg-red-500/15 text-red-400'}`}>
                    {isPositive ? '+' : ''}{change.toFixed(2)}%
                  </span>
                )}
              </div>
              <MobileNavLink href="/" icon={<TrendingUp className="h-4 w-4" />} label="Dashboard" onClick={() => setMobileMenuOpen(false)} />
              <MobileNavLink href="/signals" icon={<Zap className="h-4 w-4" />} label="Signals" onClick={() => setMobileMenuOpen(false)} />
              <MobileNavLink href="/backtest" icon={<BarChart3 className="h-4 w-4" />} label="Backtest" onClick={() => setMobileMenuOpen(false)} />
              <MobileNavLink href="/history" icon={<Clock className="h-4 w-4" />} label="History" onClick={() => setMobileMenuOpen(false)} />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

function NavLink({ href, icon, label }: { href: string; icon: React.ReactNode; label: string }) {
  return (
    <Link
      href={href}
      className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary/80 transition-all"
    >
      {icon}
      {label}
    </Link>
  );
}

function MobileNavLink({ href, icon, label, onClick }: { href: string; icon: React.ReactNode; label: string; onClick: () => void }) {
  return (
    <Link
      href={href}
      onClick={onClick}
      className="flex items-center gap-2 px-3 py-2.5 text-sm font-medium rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary/80 transition-all"
    >
      {icon}
      {label}
    </Link>
  );
}
