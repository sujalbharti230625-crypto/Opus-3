'use client';

import { useState, useEffect, useCallback } from 'react';
import { Zap, RefreshCw } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import PriceChart from './price-chart';
import RsiMacdChart from './rsi-macd-chart';
import StatsGrid from './stats-grid';
import SignalCard from './signal-card';

export default function DashboardClient() {
  const [ticker, setTicker] = useState<{ price: number; change24h: number; volume24h: number } | null>(null);
  const [signals, setSignals] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      const [tickerRes, signalsRes] = await Promise.all([
        fetch('/api/ticker'),
        fetch('/api/signals?limit=10'),
      ]);
      if (tickerRes.ok) {
        const data = await tickerRes.json();
        setTicker(data);
      }
      if (signalsRes.ok) {
        const data = await signalsRes.json();
        setSignals(data?.signals ?? []);
      }
    } catch (e: any) {
      console.error('Dashboard fetch error:', e?.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 30000);
    return () => clearInterval(interval);
  }, [fetchData]);

  const generateSignals = async () => {
    try {
      setGenerating(true);
      toast.info('Analyzing market data and generating signals...');
      const res = await fetch('/api/signals', { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        toast.success(data?.message ?? 'Signals generated');
        fetchData();
      } else {
        toast.error('Failed to generate signals');
      }
    } catch (e: any) {
      console.error('Signal gen error:', e?.message);
      toast.error('Error generating signals');
    } finally {
      setGenerating(false);
    }
  };

  const activeSignals = (signals ?? []).filter((s: any) => s?.status === 'ACTIVE');
  const closedSignals = (signals ?? []).filter((s: any) => s?.status !== 'ACTIVE');
  const wins = closedSignals.filter((s: any) => s?.status?.includes?.('TP'));
  const winRate = (closedSignals?.length ?? 0) > 0 ? (wins.length / closedSignals.length) * 100 : 0;

  return (
    <div className="space-y-6">
      {/* Stats */}
      <StatsGrid
        ticker={ticker}
        signalCount={signals?.length ?? 0}
        activeSignals={activeSignals?.length ?? 0}
        winRate={winRate}
      />

      {/* Chart */}
      <PriceChart />

      {/* RSI & MACD */}
      <RsiMacdChart />

      {/* Signal Generation */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
        className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 rounded-xl bg-card border border-border/50 p-4"
      >
        <div>
          <h2 className="font-display text-lg font-bold tracking-tight flex items-center gap-2">
            <Zap className="h-5 w-5 text-primary" />
            Trading Signals
          </h2>
          <p className="text-sm text-muted-foreground mt-0.5">Auto-generated using multi-timeframe technical analysis confluence</p>
        </div>
        <button
          onClick={generateSignals}
          disabled={generating}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 disabled:opacity-50 transition-all"
        >
          <RefreshCw className={`h-4 w-4 ${generating ? 'animate-spin' : ''}`} />
          {generating ? 'Analyzing...' : 'Generate Signals'}
        </button>
      </motion.div>

      {/* Active Signals */}
      {(activeSignals?.length ?? 0) > 0 && (
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Active Signals</h3>
          {activeSignals.map((s: any, i: number) => (
            <SignalCard key={s?.id ?? i} signal={s} index={i} />
          ))}
        </div>
      )}

      {/* Recent Closed */}
      {(closedSignals?.length ?? 0) > 0 && (
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Recent Results</h3>
          {closedSignals.slice(0, 5).map((s: any, i: number) => (
            <SignalCard key={s?.id ?? i} signal={s} index={i} />
          ))}
        </div>
      )}

      {(signals?.length ?? 0) === 0 && !loading && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="rounded-xl bg-card border border-border/50 p-8 text-center"
        >
          <Zap className="h-8 w-8 text-muted-foreground/50 mx-auto mb-3" />
          <p className="text-muted-foreground text-sm">No signals yet. Click &quot;Generate Signals&quot; to analyze the market.</p>
        </motion.div>
      )}
    </div>
  );
}
