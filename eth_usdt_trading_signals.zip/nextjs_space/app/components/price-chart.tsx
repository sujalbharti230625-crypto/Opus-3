'use client';

import { useState, useEffect, useCallback } from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, LineChart, Line, ComposedChart } from 'recharts';
import { TrendingUp, TrendingDown, Minus, RefreshCw } from 'lucide-react';
import { motion } from 'framer-motion';

interface CandleData {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

interface Indicators {
  rsi: number[];
  macd: { macd: number[]; signal: number[]; histogram: number[] };
  sma20: number[];
  sma50: number[];
  supports: number[];
  resistances: number[];
  trend: string;
  patterns: string[];
}

const timeframes = [
  { label: '15m', value: '15m' },
  { label: '1H', value: '1h' },
  { label: '4H', value: '4h' },
  { label: '1D', value: '1d' },
];

export default function PriceChart() {
  const [candles, setCandles] = useState<CandleData[]>([]);
  const [indicators, setIndicators] = useState<Indicators | null>(null);
  const [timeframe, setTimeframe] = useState('1h');
  const [loading, setLoading] = useState(true);
  const [showVolume, setShowVolume] = useState(false);
  const [showIndicators, setShowIndicators] = useState(true);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      const res = await fetch(`/api/candles?timeframe=${timeframe}&indicators=true`);
      if (res.ok) {
        const data = await res.json();
        setCandles(data?.candles ?? []);
        setIndicators(data?.indicators ?? null);
      }
    } catch (e: any) {
      console.error('Chart data error:', e?.message);
    } finally {
      setLoading(false);
    }
  }, [timeframe]);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 60000);
    return () => clearInterval(interval);
  }, [fetchData]);

  const chartData = (candles ?? []).map((c: CandleData, i: number) => {
    const date = new Date(c?.timestamp ?? 0);
    const label = timeframe === '1d'
      ? date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
      : date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });

    return {
      time: label,
      price: c?.close ?? 0,
      open: c?.open ?? 0,
      high: c?.high ?? 0,
      low: c?.low ?? 0,
      volume: c?.volume ?? 0,
      sma20: indicators?.sma20?.[i - ((candles?.length ?? 0) - (indicators?.sma20?.length ?? 0))] ?? undefined,
      sma50: indicators?.sma50?.[i - ((candles?.length ?? 0) - (indicators?.sma50?.length ?? 0))] ?? undefined,
    };
  });

  const currentPrice = (candles?.length ?? 0) > 0 ? candles[candles.length - 1]?.close ?? 0 : 0;
  const prevPrice = (candles?.length ?? 0) > 1 ? candles[candles.length - 2]?.close ?? 0 : 0;
  const priceChange = prevPrice > 0 ? ((currentPrice - prevPrice) / prevPrice) * 100 : 0;
  const trendLabel = indicators?.trend ?? 'LOADING';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="rounded-xl bg-card border border-border/50 overflow-hidden"
    >
      {/* Chart Header */}
      <div className="p-4 sm:p-5 border-b border-border/50">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-display text-xl font-bold tracking-tight">ETH/USDT</h2>
              <span className={`inline-flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded-full ${
                trendLabel === 'UPTREND' ? 'bg-emerald-500/15 text-emerald-400' :
                trendLabel === 'DOWNTREND' ? 'bg-red-500/15 text-red-400' :
                'bg-yellow-500/15 text-yellow-400'
              }`}>
                {trendLabel === 'UPTREND' ? <TrendingUp className="h-3 w-3" /> :
                 trendLabel === 'DOWNTREND' ? <TrendingDown className="h-3 w-3" /> :
                 <Minus className="h-3 w-3" />}
                {trendLabel}
              </span>
            </div>
            {(indicators?.patterns?.length ?? 0) > 0 && (
              <div className="flex flex-wrap gap-1 mt-1.5">
                {(indicators?.patterns ?? []).map((p: string, i: number) => (
                  <span key={i} className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-primary/10 text-primary">
                    {p?.replace?.(/_/g, ' ') ?? ''}
                  </span>
                ))}
              </div>
            )}
          </div>

          <div className="flex items-center gap-2">
            {/* Timeframe selector */}
            <div className="flex items-center bg-secondary/50 rounded-lg p-0.5">
              {timeframes.map((tf: { label: string; value: string }) => (
                <button
                  key={tf.value}
                  onClick={() => setTimeframe(tf.value)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all ${
                    timeframe === tf.value
                      ? 'bg-primary text-primary-foreground shadow-sm'
                      : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {tf.label}
                </button>
              ))}
            </div>

            {/* Toggle buttons */}
            <button
              onClick={() => setShowVolume(!showVolume)}
              className={`px-2.5 py-1.5 text-xs font-medium rounded-lg transition-all ${
                showVolume ? 'bg-primary/20 text-primary' : 'bg-secondary/50 text-muted-foreground hover:text-foreground'
              }`}
            >
              Vol
            </button>
            <button
              onClick={() => setShowIndicators(!showIndicators)}
              className={`px-2.5 py-1.5 text-xs font-medium rounded-lg transition-all ${
                showIndicators ? 'bg-primary/20 text-primary' : 'bg-secondary/50 text-muted-foreground hover:text-foreground'
              }`}
            >
              SMA
            </button>
            <button
              onClick={fetchData}
              className="p-1.5 rounded-lg bg-secondary/50 text-muted-foreground hover:text-foreground transition-all"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>
      </div>

      {/* Price Chart */}
      <div className="p-4">
        {loading && (chartData?.length ?? 0) === 0 ? (
          <div className="h-[350px] flex items-center justify-center">
            <div className="flex flex-col items-center gap-2">
              <RefreshCw className="h-6 w-6 text-primary animate-spin" />
              <span className="text-sm text-muted-foreground">Loading chart data...</span>
            </div>
          </div>
        ) : (
          <div className="h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={chartData} margin={{ top: 5, right: 5, left: 5, bottom: 5 }}>
                <defs>
                  <linearGradient id="priceGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#10b981" stopOpacity={0.3} />
                    <stop offset="100%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis
                  dataKey="time"
                  tickLine={false}
                  tick={{ fontSize: 10 }}
                  axisLine={false}
                  interval="preserveStartEnd"
                  minTickGap={40}
                />
                <YAxis
                  domain={['auto', 'auto']}
                  tickLine={false}
                  tick={{ fontSize: 10 }}
                  axisLine={false}
                  width={60}
                  tickFormatter={(v: number) => `$${v?.toFixed?.(0) ?? '0'}`}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'hsl(222 47% 8%)',
                    border: '1px solid hsl(222 30% 16%)',
                    borderRadius: '8px',
                    fontSize: 11,
                    color: 'hsl(210 40% 96%)',
                  }}
                  formatter={(value: any) => [`$${Number(value)?.toFixed?.(2) ?? '0'}`, '']}
                />
                <Area
                  type="monotone"
                  dataKey="price"
                  stroke="#10b981"
                  strokeWidth={2}
                  fill="url(#priceGradient)"
                  name="Price"
                />
                {showIndicators && (
                  <>
                    <Line type="monotone" dataKey="sma20" stroke="#60B5FF" strokeWidth={1} dot={false} name="SMA 20" connectNulls />
                    <Line type="monotone" dataKey="sma50" stroke="#FF9149" strokeWidth={1} dot={false} name="SMA 50" connectNulls />
                  </>
                )}
                {showVolume && (
                  <Bar dataKey="volume" fill="#60B5FF" opacity={0.2} yAxisId="volume" name="Volume" />
                )}
                {showVolume && (
                  <YAxis yAxisId="volume" orientation="right" hide />
                )}
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      {/* Support/Resistance zones */}
      {indicators && ((indicators?.supports?.length ?? 0) > 0 || (indicators?.resistances?.length ?? 0) > 0) && (
        <div className="px-4 pb-4">
          <div className="flex flex-wrap gap-2">
            {(indicators?.supports ?? []).slice(0, 3).map((s: number, i: number) => (
              <span key={`s-${i}`} className="text-[10px] font-mono px-2 py-1 rounded-md bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                Support: ${s?.toFixed?.(2) ?? '0'}
              </span>
            ))}
            {(indicators?.resistances ?? []).slice(0, 3).map((r: number, i: number) => (
              <span key={`r-${i}`} className="text-[10px] font-mono px-2 py-1 rounded-md bg-red-500/10 text-red-400 border border-red-500/20">
                Resistance: ${r?.toFixed?.(2) ?? '0'}
              </span>
            ))}
          </div>
        </div>
      )}
    </motion.div>
  );
}
