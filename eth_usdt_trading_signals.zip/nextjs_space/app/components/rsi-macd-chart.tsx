'use client';

import { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, ReferenceLine, Cell } from 'recharts';
import { Activity } from 'lucide-react';
import { motion } from 'framer-motion';

export default function RsiMacdChart() {
  const [indicators, setIndicators] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch('/api/candles?timeframe=1h&indicators=true');
        if (res.ok) {
          const data = await res.json();
          setIndicators(data?.indicators ?? null);
        }
      } catch (e: any) {
        console.error('Indicator fetch error:', e?.message);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
    const interval = setInterval(fetchData, 60000);
    return () => clearInterval(interval);
  }, []);

  const rsiData = (indicators?.rsi ?? []).map((val: number, i: number) => ({
    index: i,
    rsi: Math.round((val ?? 0) * 100) / 100,
  }));

  const macdData = (indicators?.macd?.histogram ?? []).map((val: number, i: number) => ({
    index: i,
    histogram: Math.round((val ?? 0) * 100) / 100,
    macd: Math.round((indicators?.macd?.macd?.[i + ((indicators?.macd?.macd?.length ?? 0) - (indicators?.macd?.histogram?.length ?? 0))] ?? 0) * 100) / 100,
    signal: Math.round((indicators?.macd?.signal?.[i] ?? 0) * 100) / 100,
  }));

  const currentRSI = rsiData?.length > 0 ? rsiData[rsiData.length - 1]?.rsi ?? 50 : 50;
  const rsiColor = currentRSI > 70 ? '#ef4444' : currentRSI < 30 ? '#10b981' : '#60B5FF';

  if (loading) {
    return (
      <div className="rounded-xl bg-card border border-border/50 p-5 h-[300px] flex items-center justify-center">
        <div className="flex items-center gap-2 text-muted-foreground">
          <Activity className="h-4 w-4 animate-pulse" />
          <span className="text-sm">Loading indicators...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      {/* RSI Chart */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="rounded-xl bg-card border border-border/50 p-4"
      >
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold flex items-center gap-1.5">
            <Activity className="h-4 w-4 text-primary" />
            RSI (14)
          </h3>
          <span className="font-mono text-sm font-bold" style={{ color: rsiColor }}>
            {currentRSI?.toFixed?.(1) ?? '50'}
          </span>
        </div>
        <div className="h-[160px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={rsiData} margin={{ top: 5, right: 5, left: 0, bottom: 5 }}>
              <XAxis dataKey="index" hide />
              <YAxis domain={[0, 100]} tickLine={false} tick={{ fontSize: 10 }} axisLine={false} width={30} />
              <ReferenceLine y={70} stroke="#ef4444" strokeDasharray="3 3" strokeOpacity={0.5} />
              <ReferenceLine y={30} stroke="#10b981" strokeDasharray="3 3" strokeOpacity={0.5} />
              <Tooltip
                contentStyle={{ backgroundColor: 'hsl(222 47% 8%)', border: '1px solid hsl(222 30% 16%)', borderRadius: '8px', fontSize: 11, color: 'hsl(210 40% 96%)' }}
              />
              <Line type="monotone" dataKey="rsi" stroke={rsiColor} strokeWidth={1.5} dot={false} name="RSI" />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="flex items-center justify-between mt-2 text-[10px] font-mono text-muted-foreground">
          <span className="text-emerald-400">Oversold &lt; 30</span>
          <span className="text-red-400">Overbought &gt; 70</span>
        </div>
      </motion.div>

      {/* MACD Chart */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="rounded-xl bg-card border border-border/50 p-4"
      >
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold flex items-center gap-1.5">
            <Activity className="h-4 w-4 text-primary" />
            MACD (12, 26, 9)
          </h3>
        </div>
        <div className="h-[160px]">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedMacdChart data={macdData} />
          </ResponsiveContainer>
        </div>
        <div className="flex items-center justify-between mt-2 text-[10px] font-mono text-muted-foreground">
          <span className="text-emerald-400">Bullish: histogram above 0</span>
          <span className="text-red-400">Bearish: histogram below 0</span>
        </div>
      </motion.div>
    </div>
  );
}

// Separate composed MACD chart to avoid hook issues
function ComposedMacdChart({ data }: { data: any[] }) {
  return (
    <BarChart data={data} margin={{ top: 5, right: 5, left: 0, bottom: 5 }}>
      <XAxis dataKey="index" hide />
      <YAxis tickLine={false} tick={{ fontSize: 10 }} axisLine={false} width={40} />
      <Tooltip
        contentStyle={{ backgroundColor: 'hsl(222 47% 8%)', border: '1px solid hsl(222 30% 16%)', borderRadius: '8px', fontSize: 11, color: 'hsl(210 40% 96%)' }}
      />
      <ReferenceLine y={0} stroke="hsl(222 30% 16%)" />
      <Bar dataKey="histogram" name="Histogram">
        {(data ?? []).map((entry: any, index: number) => (
          <Cell key={index} fill={(entry?.histogram ?? 0) >= 0 ? '#10b981' : '#ef4444'} opacity={0.7} />
        ))}
      </Bar>
    </BarChart>
  );
}
