'use client';

import { ArrowUpCircle, ArrowDownCircle, Target, Shield, TrendingUp, Clock, Zap } from 'lucide-react';
import { motion } from 'framer-motion';

interface SignalProps {
  signal: {
    id: number;
    type: string;
    entryPrice: number;
    stopLoss: number;
    target1: number;
    target2: number;
    target3: number;
    confidence: number;
    riskReward: number;
    reasoning: string;
    status: string;
    timeframe: string;
    createdAt: string;
    pnlPercent?: number | null;
    outcome?: string | null;
  };
  index?: number;
}

export default function SignalCard({ signal, index = 0 }: SignalProps) {
  const s = signal ?? {} as any;
  const isBuy = s?.type === 'BUY';
  const isActive = s?.status === 'ACTIVE';
  const isWin = s?.status?.includes?.('TP') ?? false;
  const isLoss = s?.status === 'STOPPED_OUT';

  const statusColors: Record<string, string> = {
    ACTIVE: 'bg-blue-500/15 text-blue-400 border-blue-500/20',
    TP1_HIT: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/20',
    TP2_HIT: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/20',
    TP3_HIT: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/20',
    STOPPED_OUT: 'bg-red-500/15 text-red-400 border-red-500/20',
    EXPIRED: 'bg-yellow-500/15 text-yellow-400 border-yellow-500/20',
  };

  const createdDate = s?.createdAt ? new Date(s.createdAt) : new Date();

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.05 }}
      className={`rounded-xl border overflow-hidden transition-all hover:shadow-lg ${
        isBuy
          ? 'bg-emerald-500/[0.03] border-emerald-500/20 hover:border-emerald-500/40'
          : 'bg-red-500/[0.03] border-red-500/20 hover:border-red-500/40'
      }`}
    >
      {/* Header */}
      <div className="p-4 pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {isBuy ? (
              <ArrowUpCircle className="h-5 w-5 text-emerald-400" />
            ) : (
              <ArrowDownCircle className="h-5 w-5 text-red-400" />
            )}
            <span className={`font-display text-lg font-bold ${isBuy ? 'text-emerald-400' : 'text-red-400'}`}>
              {s?.type ?? 'UNKNOWN'}
            </span>
            <span className="text-xs font-mono text-muted-foreground bg-secondary/50 px-1.5 py-0.5 rounded">
              {s?.timeframe ?? '1h'}
            </span>
          </div>
          <span className={`text-[10px] font-medium px-2 py-0.5 rounded-full border ${statusColors[s?.status ?? ''] ?? statusColors.ACTIVE}`}>
            {s?.status?.replace?.(/_/g, ' ') ?? 'UNKNOWN'}
          </span>
        </div>

        {/* Confidence */}
        <div className="flex items-center gap-3 mt-2">
          <div className="flex items-center gap-1">
            <Zap className="h-3 w-3 text-primary" />
            <span className="text-xs text-muted-foreground">Confidence:</span>
            <span className="text-xs font-mono font-bold text-primary">{s?.confidence ?? 0}%</span>
          </div>
          <div className="flex items-center gap-1">
            <Shield className="h-3 w-3 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">R:R</span>
            <span className="text-xs font-mono font-bold">{s?.riskReward?.toFixed?.(2) ?? '0'}</span>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="h-3 w-3 text-muted-foreground" />
            <span className="text-xs font-mono text-muted-foreground">
              {createdDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
            </span>
          </div>
        </div>
      </div>

      {/* Price levels */}
      <div className="px-4 pb-3">
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
          <PriceLevel label="Entry" value={s?.entryPrice ?? 0} color="text-foreground" />
          <PriceLevel label="Stop Loss" value={s?.stopLoss ?? 0} color="text-red-400" />
          <PriceLevel label="TP1" value={s?.target1 ?? 0} color="text-emerald-400" />
          <PriceLevel label="TP2" value={s?.target2 ?? 0} color="text-emerald-400" />
          <PriceLevel label="TP3" value={s?.target3 ?? 0} color="text-emerald-400" />
        </div>
      </div>

      {/* Reasoning */}
      <div className="px-4 pb-3">
        <div className="flex flex-wrap gap-1">
          {(s?.reasoning?.split?.(' | ') ?? []).map((r: string, i: number) => (
            <span key={i} className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-secondary/60 text-muted-foreground">
              {r}
            </span>
          ))}
        </div>
      </div>

      {/* PnL */}
      {s?.pnlPercent != null && (
        <div className={`px-4 py-2 text-xs font-mono font-medium flex items-center gap-1 ${
          (s?.pnlPercent ?? 0) >= 0 ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'
        }`}>
          <TrendingUp className="h-3 w-3" />
          PnL: {(s?.pnlPercent ?? 0) >= 0 ? '+' : ''}{s?.pnlPercent?.toFixed?.(2) ?? '0'}%
          {s?.outcome && <span className="ml-2 opacity-70">— {s.outcome}</span>}
        </div>
      )}
    </motion.div>
  );
}

function PriceLevel({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="text-center p-1.5 rounded-lg bg-secondary/30">
      <div className="text-[10px] text-muted-foreground mb-0.5">{label}</div>
      <div className={`text-xs font-mono font-bold ${color}`}>
        ${value?.toFixed?.(2) ?? '0.00'}
      </div>
    </div>
  );
}
