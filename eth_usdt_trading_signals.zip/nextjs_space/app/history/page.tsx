import Header from '../components/header';
import HistoryClient from './history-client';

export default function HistoryPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="mx-auto max-w-[1200px] px-4 py-6">
        <div className="mb-6">
          <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight">
            Signal <span className="text-primary">History</span>
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Track record of all past trading signals and their outcomes
          </p>
        </div>
        <HistoryClient />
      </main>
    </div>
  );
}
