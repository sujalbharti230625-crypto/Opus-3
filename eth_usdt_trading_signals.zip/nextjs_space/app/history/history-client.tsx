'use client';

import { useState, useEffect, useCallback } from 'react';
import { Clock, TrendingUp, TrendingDown, Target, ArrowUpCircle, ArrowDownCircle, Filter, BarChart3 } from 'lucide-react';
import { motion } from 'framer-motion';
import SignalCard from '../components/signal-card';

export default function HistoryClient() {
  const [signals, setSignals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [typeFilter, setTypeFilter] = useState('');

  const fetchSignals = useCallback(async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/signals?limit=100');
      if (res.ok) {
        const data = await res.json();
        setSignals((data?.signals ?? []).filter((s: any) => s?.status !== 'ACTIVE'));
      }
    } catch (e: any) {
      console.error('History fetch error:', e?.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchSignals();
  }, [fetchSignals]);

  const filtered = (signals ?? []).filter((s: any) => {
    if (!typeFilter) return true;
    return s?.type === typeFilter;
  });

  const wins = filtered.filter((s: any) => s?.status?.includes?.('TP'));
  const losses = filtered.filter((s: any) => s?.status === 'STOPPED_OUT');
  const totalPnl = filtered.reduce((sum: number, s: any) => sum + (s?.pnlPercent ?? 0), 0);

  return (
    <div className="space-y-6">
      {/* Summary stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <SummaryCard
          icon={<BarChart3 className="h-4 w-4" />}
          label="Total Closed"
          value={`${filtered?.length ?? 0}`}
          delay={0}
        />
        <SummaryCard
          icon={<Target className="h-4 w-4" />}
          label="Win Rate"
          value={`${(filtered?.length ?? 0) > 0 ? ((wins.length / filtered.length) * 100).toFixed(1) : '0'}%`}
          positive={(wins?.length ?? 0) > (losses?.length ?? 0)}
          delay={0.05}
        />
        <SummaryCard
          icon={<TrendingUp className="h-4 w-4" />}
          label="Wins"
          value={`${wins?.length ?? 0}`}
          positive
          delay={0.1}
        />
        <SummaryCard
          icon={<TrendingDown className="h-4 w-4" />}
          label="Cumulative PnL"
          value={`${totalPnl >= 0 ? '+' : ''}${totalPnl?.toFixed?.(2) ?? '0'}%`}
          positive={totalPnl >= 0}
          delay={0.15}
        />
      </div>

      {/* Filter */}
      <div className="flex items-center gap-2">
        <Filter className="h-3.5 w-3.5 text-muted-foreground" />
        <div className="flex items-center gap-1 bg-secondary/50 rounded-lg p-0.5">
          {[
            { label: 'All', value: '' },
            { label: 'Buy', value: 'BUY' },
            { label: 'Sell', value: 'SELL' },
          ].map((f: { label: string; value: string }) => (
            <button
              key={f.value}
              onClick={() => setTypeFilter(f.value)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all ${
                typeFilter === f.value
                  ? 'bg-primary text-primary-foreground shadow-sm'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Signal list */}
      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i: number) => (
            <div key={i} className="h-40 rounded-xl bg-card border border-border/50 animate-pulse" />
          ))}
        </div>
      ) : (filtered?.length ?? 0) > 0 ? (
        <div className="space-y-3">
          {filtered.map((s: any, i: number) => (
            <SignalCard key={s?.id ?? i} signal={s} index={i} />
          ))}
        </div>
      ) : (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="rounded-xl bg-card border border-border/50 p-12 text-center"
        >
          <Clock className="h-10 w-10 text-muted-foreground/30 mx-auto mb-3" />
          <p className="text-muted-foreground">No closed signals yet. Generate signals from the dashboard to start tracking history.</p>
        </motion.div>
      )}
    </div>
  );
}

function SummaryCard({ icon, label, value, positive, delay = 0 }: {
  icon: React.ReactNode;
  label: string;
  value: string;
  positive?: boolean;
  delay?: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay }}
      className="rounded-xl bg-card border border-border/50 p-4 hover:border-primary/30 transition-all"
    >
      <div className="flex items-center gap-2 mb-1.5">
        <div className="text-primary">{icon}</div>
        <span className="text-xs text-muted-foreground">{label}</span>
      </div>
      <span className={`font-mono text-lg font-bold ${
        positive === true ? 'text-emerald-400' : positive === false ? 'text-red-400' : ''
      }`}>
        {value}
      </span>
    </motion.div>
  );
}
