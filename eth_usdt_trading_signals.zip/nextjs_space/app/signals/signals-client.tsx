'use client';

import { useState, useEffect, useCallback } from 'react';
import { Zap, RefreshCw, Filter } from 'lucide-react';
import { toast } from 'sonner';
import SignalCard from '../components/signal-card';
import { motion } from 'framer-motion';

const statusFilters = [
  { label: 'All', value: '' },
  { label: 'Active', value: 'ACTIVE' },
  { label: 'TP Hit', value: 'TP' },
  { label: 'Stopped', value: 'STOPPED_OUT' },
  { label: 'Expired', value: 'EXPIRED' },
];

export default function SignalsPageClient() {
  const [signals, setSignals] = useState<any[]>([]);
  const [filter, setFilter] = useState('');
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);

  const fetchSignals = useCallback(async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/signals?limit=50');
      if (res.ok) {
        const data = await res.json();
        setSignals(data?.signals ?? []);
      }
    } catch (e: any) {
      console.error('Signals fetch error:', e?.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchSignals();
  }, [fetchSignals]);

  const generateSignals = async () => {
    try {
      setGenerating(true);
      toast.info('Analyzing market and generating signals...');
      const res = await fetch('/api/signals', { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        toast.success(data?.message ?? 'Signals generated');
        fetchSignals();
      } else {
        toast.error('Failed to generate signals');
      }
    } catch (e: any) {
      toast.error('Error generating signals');
    } finally {
      setGenerating(false);
    }
  };

  const filtered = (signals ?? []).filter((s: any) => {
    if (!filter) return true;
    if (filter === 'TP') return s?.status?.includes?.('TP');
    return s?.status === filter;
  });

  return (
    <div className="space-y-4">
      {/* Controls */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-1 bg-secondary/50 rounded-lg p-0.5">
          <Filter className="h-3.5 w-3.5 text-muted-foreground ml-2 mr-1" />
          {statusFilters.map((f: { label: string; value: string }) => (
            <button
              key={f.value}
              onClick={() => setFilter(f.value)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all ${
                filter === f.value
                  ? 'bg-primary text-primary-foreground shadow-sm'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        <button
          onClick={generateSignals}
          disabled={generating}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 disabled:opacity-50 transition-all"
        >
          <RefreshCw className={`h-4 w-4 ${generating ? 'animate-spin' : ''}`} />
          {generating ? 'Analyzing...' : 'Generate New Signals'}
        </button>
      </div>

      {/* Signals List */}
      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i: number) => (
            <div key={i} className="h-40 rounded-xl bg-card border border-border/50 animate-pulse" />
          ))}
        </div>
      ) : (filtered?.length ?? 0) > 0 ? (
        <div className="space-y-3">
          {filtered.map((s: any, i: number) => (
            <SignalCard key={s?.id ?? i} signal={s} index={i} />
          ))}
        </div>
      ) : (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="rounded-xl bg-card border border-border/50 p-12 text-center"
        >
          <Zap className="h-10 w-10 text-muted-foreground/30 mx-auto mb-3" />
          <p className="text-muted-foreground">
            {filter ? 'No signals match this filter.' : 'No signals generated yet. Click Generate to start.'}
          </p>
        </motion.div>
      )}
    </div>
  );
}
