import Header from '../components/header';
import SignalsPageClient from './signals-client';

export default function SignalsPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="mx-auto max-w-[1200px] px-4 py-6">
        <div className="mb-6">
          <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight">
            Trading <span className="text-primary">Signals</span>
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            All generated signals with entry, stop loss, and target levels
          </p>
        </div>
        <SignalsPageClient />
      </main>
    </div>
  );
}
